-- Join recipe (pseudo-SQL)
-- Inputs: sales (Deliverect/Marn), ads (Snap/TikTok)
-- Output: daily unified with CPA, ROAS, AOV
WITH sales AS (
  SELECT date, SUM(orders) AS orders, SUM(net_sales_sar) AS net_sales_sar
  FROM input_sales
  GROUP BY date
),
ads AS (
  SELECT date, SUM(spend_sar) AS spend_sar, SUM(attributed_orders) AS attributed_orders, SUM(attributed_sales_sar) AS attributed_sales_sar
  FROM input_ads
  GROUP BY date
)
SELECT
  s.date,
  s.orders,
  s.net_sales_sar,
  COALESCE(a.spend_sar,0) AS ad_spend_sar,
  ROUND(CASE WHEN s.orders>0 THEN s.net_sales_sar*1.0/s.orders ELSE 0 END,2) AS aov_sar,
  ROUND(CASE WHEN COALESCE(a.attributed_orders,0)>0 THEN a.spend_sar*1.0/a.attributed_orders ELSE NULL END,2) AS cpa_sar,
  ROUND(CASE WHEN COALESCE(a.spend_sar,0)>0 THEN a.attributed_sales_sar*1.0/a.spend_sar ELSE NULL END,2) AS roas
FROM sales s
LEFT JOIN ads a ON a.date = s.date
ORDER BY s.date;
