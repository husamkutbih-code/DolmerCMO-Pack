# CMO Training Kit (Simulation Mode)

This kit lets you **train and rehearse** your CMO AI agents (CMO GPT + assistants) before live API access
(TikTok, Snapchat, Deliverect, Marn). Use the mock data and prompts to practice the full workflow end‑to‑end.

## Contents
- `knowledge_base/` – brand, KPIs, creative rules, report templates.
- `mock_data/` – fake but realistic sales & ads performance.
- `schemas/` – unified schemas you should adopt across sources.
- `prompts/` – system and role prompts for each agent.
- `evaluation/` – rubric and test cases to score agent outputs.
- `n8n/workflows/` – example n8n JSON you can adapt.
- `security/` – sample env & rotation guide.

## Quick Start
1) Load `knowledge_base/` into your vector store (Supabase/Pinecone).
2) Feed `mock_data/` to your n8n workflows (HTTP Request → Move to Merge nodes, or Function nodes).
3) Use the prompts in `prompts/` as System/Instruction for each agent in your orchestrator.
4) Generate Daily Report → compare using `evaluation/rubric.md`.
5) Iterate on prompts and mapping until quality ≥ 85% by the rubric.
