# KPI Definitions
- Orders: Count of completed transactions.
- Net Sales (SAR): Sales excl. VAT & discounts.
- AOV: Net Sales / Orders.
- Ad Spend (SAR): Paid media cost by platform.
- CPA (per order): Ad Spend / Orders attributed.
- ROAS: Net Sales Attributed / Ad Spend.
- CTR: Clicks / Impressions.
- VTR (Video): Thru-plays / Impressions.
- SLA: % of orders delivered ≤ 35 minutes.
Thresholds (initial):
- CPA target ≤ 12 SAR
- ROAS target ≥ 2.5x
- Weekend orders ≥ weekday avg +15%
