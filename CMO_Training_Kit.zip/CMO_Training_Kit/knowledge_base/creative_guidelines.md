# Creative Guidelines
- Hooks: family gatherings, weekend boxes, comfort food, Saudi dialect.
- Always include: price anchor, availability, CTA, branch coverage.
- Formats: 9:16 vertical first, 15s & 6s variants.
- Testing: 3 hooks × 2 edits × 2 CTAs = 12 creatives per sprint.
