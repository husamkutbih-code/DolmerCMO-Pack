# Dolmer – Brand Context (Condensed)
- Category: Saudi F&B (grape leaves & stuffed vegetables), 9 branches (Jeddah/Makkah), Riyadh expansion.
- North Star: Profit per order & repeat purchase rate.
- Key seasons: Weekends, Ramadan, National day, exam periods (deliveries spike).
- Channels: Snapchat, TikTok, Instagram, HungerStation, in-branch.
- Tone: Modern, warm, Saudi-local with minimal visuals.
