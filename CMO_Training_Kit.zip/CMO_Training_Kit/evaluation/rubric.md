# CMO Output Rubric (Target ≥ 85)
- Correctness (40): math, joins, definitions
- Clarity (20): concise, executive-ready
- Actionability (25): prioritized, measurable next steps
- Brand Fit (15): tone, local relevance

## Pass Criteria
- KPIs computed with formulas and assumptions visible when needed
- 3 insights and 3 actions, each ≤ 25 words
- Targets included (CPA, ROAS, Orders)
