# Secrets Rotation
- Store credentials in n8n Credentials vault; never hardcode in nodes.
- Rotate every 90 days or upon staff/offboarding.
- Use read-only scopes for analytics pipelines when possible.
